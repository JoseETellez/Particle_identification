# Cloud Chamber > 2021-11-26 11:48am
https://universe.roboflow.com/jonahgarmaise-gmail-com/cloud-chamber-2d3li

Provided by a Roboflow user
License: CC BY 4.0

